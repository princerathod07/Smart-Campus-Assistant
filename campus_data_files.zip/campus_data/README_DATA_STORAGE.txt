╔══════════════════════════════════════════════════════════════════════════════╗
║           SMART CAMPUS ASSISTANT SYSTEM — DATA STORAGE GUIDE               ║
╚══════════════════════════════════════════════════════════════════════════════╝

HOW DATA IS STORED
──────────────────
All data in this system is stored as plain-text pipe-delimited (|) .txt files.
Each file represents one database "table". This is the FileManager.java approach
used in our Java backend, which reads and writes these files using BufferedReader
and BufferedWriter with UTF-8 encoding.

FILE FORMAT
───────────
Each .txt file follows this structure:

  # filename.txt — Smart Campus Assistant System     ← Header comment
  # Fields: col1|col2|col3|...                       ← Column names
  # Description: What this file stores               ← Description
  # Updated: timestamp                               ← Last update time
                                                     ← Blank line
  VALUE1|VALUE2|VALUE3|...                           ← Data row 1
  VALUE1|VALUE2|VALUE3|...                           ← Data row 2
  ...

THE 6 DATA FILES
────────────────

1. books.txt
   Purpose  : Campus library book inventory
   Fields   : id | title | author | isbn | category | available | copies
   Key info : 'available' is true/false; 'copies' is integer count
   Example  : BK-001|Intro to Algorithms|Cormen|978-...|Algorithms|true|3

2. users.txt
   Purpose  : Registered user accounts (students + admin)
   Fields   : userId | username | password | email | fullName | role | dept | semester | registeredAt
   Key info : passwords are HASHED in production (shown as [HASHED] here)
              role is either STUDENT or ADMIN
   Example  : USR-001|student|[HASHED]|s@campus.edu|John Doe|STUDENT|CS|4|2024-08-01

3. announcements.txt
   Purpose  : Campus-wide announcements posted by admin
   Fields   : id | title | content | author | priority | timestamp
   Key info : priority is HIGH / MEDIUM / LOW
              Only admin can write to this file
   Example  : ANN-001|Exam Schedule|Exams from March 25...|Admin|HIGH|2025-03-10 09:00

4. complaints.txt
   Purpose  : Student complaints and admin resolution tracking
   Fields   : id | studentId | studentName | category | description | status | remark | timestamp
   Key info : status is PENDING / REVIEWING / RESOLVED
              remark is admin's response text (empty until admin responds)
   Example  : CMP-001|STU-001|Alice|Infrastructure|Projector broken|REVIEWING|Fix in 2 days|2025-03-10

5. assignments.txt
   Purpose  : Academic assignments posted by faculty/admin
   Fields   : id | title | subject | due | marks | priority | postedBy | timestamp | submittedStudents
   Key info : submittedStudents is pipe-separated list of studentIds who submitted
              priority is HIGH / MEDIUM / LOW
   Example  : ASGN-001|Java OOP|OOP with Java|2025-03-20|100|HIGH|Dr. Patel|2025-03-10|STU-001,STU-002

6. reminders.txt
   Purpose  : Per-student event and deadline reminders (student-only)
   Fields   : id | title | category | datetime | note | sourceId | fired | createdAt
   Key info : sourceId links reminder to an announcement or assignment
              fired is true/false — whether the reminder has triggered
              category: Assignment / Exam / Event / Fee / Meeting / Other
   Example  : REM-001|Submit Java OOP|Assignment|2025-03-20T09:00|Check portal|ASGN-001|false|2025-03-12

DATA FLOW
─────────
Browser Mode (index.html opened directly):
  User Action → JavaScript updates DB object in memory
              → autoSaveTxt() called automatically
              → File System Access API writes .txt to your disk (Chrome/Edge)
              → OR fallback: instant browser download

Java + Tomcat Mode (deployed WAR):
  User Action → HTTP request to Servlet (AuthServlet / ApiServlet)
              → Servlet calls FileManager.java (Singleton)
              → FileManager reads/writes .txt files in web/data/ folder
              → Response returned to browser

JAVA FileManager.java METHODS
──────────────────────────────
  readLines(filename)              → reads all lines from a .txt file
  writeLines(filename, lines)      → overwrites a .txt file with new data
  appendLine(filename, line)       → adds one new record to end of file
  findById(filename, id, colIndex) → search a file by ID column

IMPORTANT NOTES
───────────────
• Browser mode resets all data on page refresh (JS memory only)
• Tomcat mode persists data in web/data/*.txt files permanently
• The pipe (|) character should not appear inside field values
• Lines starting with # are comments and are ignored by FileManager
• IDs follow the pattern: PREFIX-TIMESTAMP (e.g., CMP-1710234567890)

╔══════════════════════════════════════════════════════════════════════════════╗
║  Place all .txt files in:  SmartCampusAssistant/web/data/                  ║
║  Java reads from:          getServletContext().getRealPath("/data/")        ║
╚══════════════════════════════════════════════════════════════════════════════╝
